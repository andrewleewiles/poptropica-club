            </div><!-- .site-main -->
        </div><!-- .cloud-content -->
    </main><!-- .cloud-container -->

    <!-- Footer -->
    <footer class="site-footer">
        <img src="<?php echo get_template_directory_uri(); ?>/assets/wilesCreative.png" alt="Wiles Creative Studio" class="footer-logo">
        <p class="footer-disclaimer">Messy Sinker's Poptropica Club is unaffiliated with &copy; Sandbox Networks, Inc. / Sandbox International Holdings Ltd. Wiles Creative Studios claims no ownership of Poptropica intellectual-property. All original art and code &copy; <?php echo date('Y'); ?> Wiles Creative Studios.</p>
    </footer>

</div><!-- .page-wrapper -->

<?php wp_footer(); ?>
</body>
</html>
